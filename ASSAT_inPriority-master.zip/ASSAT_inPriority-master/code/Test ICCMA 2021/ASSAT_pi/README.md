## INSTRUCTIONS 

For compiling the system:

`./build`

For running the system, see the probo interfaces. For example:

`./ASSAT_pi -f $inputfile -p SE-PR -fo apx`

